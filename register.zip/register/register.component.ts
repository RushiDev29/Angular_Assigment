import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { User } from '../user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent 
{
  constructor(private router: Router,private userService:UserService) { }
    user:User = new User;
  

 
  saveUser(){
    //this.saveStudent;
    console.log("student component calling.");
    this.userService.saveUser(this.user).subscribe((result)=>{
      alert(' Save Successfully !')
      return result;

    });
  }
  
  
}
